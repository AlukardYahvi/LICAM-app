LICAM - Calculadora de Riesgo (Paquete para desplegar)
Contenido:
- index.html (archivo principal de la app)

Instrucciones rápidas:
- Descomprime este archivo y sube la carpeta a GitHub (como repo), o súbelo por drag-and-drop a Netlify / Vercel / Surge.
- Para probar localmente: en la carpeta descomprimida ejecuta:
    python -m http.server 8000
  y abre http://localhost:8000 en tu navegador.
